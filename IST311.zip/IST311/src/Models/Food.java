package Models;

import java.util.List;

/**
 * Food Model Object
 *
 * @author NathanParker
 */
public class Food {

    //Declare Fields
    private Integer fdcId;
    private String description;
    private List<FoodNutrient> foodNutrients = null;

    /**
     * Full Constructor
     *
     * @param fdcId
     * @param description
     * @param foodNutrients
     */
    public Food(Integer fdcId, String description, List<FoodNutrient> foodNutrients) {
        this.fdcId = fdcId;
        this.description = description;
        this.foodNutrients = foodNutrients;
    }

    /**
     * Get the fdcID
     *
     * @return fdcID
     */
    public Integer getFdcId() {
        return fdcId;
    }

    /**
     * Set the fdcID
     *
     * @param fdcId
     */
    public void setFdcId(Integer fdcId) {
        this.fdcId = fdcId;
    }

    /**
     * Get the description
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the description
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Get the List of FoodNutrients
     *
     * @return foodNutrients
     */
    public List<FoodNutrient> getFoodNutrients() {
        return foodNutrients;
    }

    /**
     * Set the foodNutrients
     *
     * @param foodNutrients
     */
    public void setFoodNutrients(List<FoodNutrient> foodNutrients) {
        this.foodNutrients = foodNutrients;
    }
}
