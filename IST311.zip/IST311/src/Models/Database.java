package Models;

import java.util.ArrayList;

/**
 * Database Object That is Populated From Save File During Run time
 *
 * @author NathanParker
 */
public class Database {

    // foodList contains an Array List of each saved SearchResultDTO Object
    // totalCalories will maintain the total value of all calories logged
    private ArrayList<SearchResultDTO> foodList = new ArrayList<>();
    private double totalCalories;

    /**
     * Database constructor
     */
    public Database() {
        foodList = new ArrayList<>();
    }

    /**
     * Set the foodList to a given ArrayList of SearchResultDTO's
     *
     * @param foodList
     */
    public void setDatabaseList(ArrayList<SearchResultDTO> foodList) {
        this.foodList = foodList;
    }

    /**
     * Return the foodList
     *
     * @return foodList
     */
    public ArrayList<SearchResultDTO> getFoodList() {
        return this.foodList;
    }

    /**
     * Add a SearchResultDTO foodItem to the foodList
     *
     * @param foodItem
     */
    public void addFoodItem(SearchResultDTO foodItem) {
        this.foodList.add(foodItem);
        totalCalories = totalCalories + foodItem.getKcal();

    }

    /**
     * Get the totalCalories
     *
     * @return totalCalories
     */
    public double getTotalCalories() {
        return this.totalCalories;
    }
}
