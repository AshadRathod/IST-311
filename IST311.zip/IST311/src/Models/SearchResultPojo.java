package Models;

import java.util.List;

/**
 * SearchResultPojo Model Object that will hold our FDC API Response Correctly
 *
 * @author NathanParker
 */
public class SearchResultPojo {

    //Declare a List of Food Objects
    private List<Food> foods = null;

    /**
     * Get list of Food objects
     *
     * @return foods
     */
    public List<Food> getFoods() {
        return foods;
    }

    /**
     * Set the list of Food objects
     *
     * @param foods
     */
    public void setFoods(List<Food> foods) {
        this.foods = foods;
    }

}
