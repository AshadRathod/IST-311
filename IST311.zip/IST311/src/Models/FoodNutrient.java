package Models;

/**
 * FoodNutrient Model Object
 *
 * @author NathanParker
 */
public class FoodNutrient {

    //Declare Fields
    private Integer nutrientId;
    private String nutrientName;
    private Double value;

    /**
     * Get nutrientId
     *
     * @return nutrientId
     */
    public Integer getNutrientId() {
        return nutrientId;
    }

    /**
     * Set nutrientId
     *
     * @param nutrientId
     */
    public void setNutrientId(Integer nutrientId) {
        this.nutrientId = nutrientId;
    }

    /**
     * Get nutrientName
     *
     * @return nutrientName
     */
    public String getNutrientName() {
        return nutrientName;
    }

    /**
     * Set nutrientName
     *
     * @param nutrientName
     */
    public void setNutrientName(String nutrientName) {
        this.nutrientName = nutrientName;
    }

    /**
     * Get value
     *
     * @return value
     */
    public Double getValue() {
        return value;
    }

    /**
     * Set value
     *
     * @param value
     */
    public void setValue(Double value) {
        this.value = value;
    }

}
