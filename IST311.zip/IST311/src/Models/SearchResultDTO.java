package Models;

import java.util.ArrayList;
import java.util.List;

/**
 * SearchResultDTO Model Object
 *
 * @author NathanParker
 */
public class SearchResultDTO {

    private double kcal;
    private double protein;
    private double carbs;
    private double fat;
    private String foodName;

    /**
     * Full Constructor
     *
     * @param kcal
     * @param protein
     * @param carbs
     * @param fat
     * @param foodName
     */
    public SearchResultDTO(double kcal, double protein, double carbs, double fat, String foodName) {
        this.kcal = kcal;
        this.protein = protein;
        this.carbs = carbs;
        this.fat = fat;
        this.foodName = foodName;

    }

    /**
     * Get kcal
     *
     * @return kcal
     */
    public double getKcal() {
        return kcal;
    }

    /**
     * Set kcal
     *
     * @param kcal
     */
    public void setKcal(double kcal) {
        this.kcal = kcal;
    }

    /**
     * Get protein
     *
     * @return protein
     */
    public double getProtein() {
        return protein;

    }

    /**
     * Set protein
     *
     * @param protein
     */
    public void setProtein(double protein) {
        this.protein = protein;
    }

    /**
     * Get carbs
     *
     * @return carbs
     */
    public double getCarbs() {
        return carbs;
    }

    /**
     * Set carbs
     *
     * @param carbs
     */
    public void setCarbs(double carbs) {
        this.carbs = carbs;
    }

    /**
     * Get fat
     *
     * @return fat
     */
    public double getFat() {
        return fat;
    }

    /**
     * Set fat
     *
     * @param fat
     */
    public void setFat(double fat) {
        this.fat = fat;
    }

    /**
     * Get foodName
     *
     * @return foodName
     */
    public String getFoodName() {
        return foodName;
    }

    /**
     * Set foodName
     *
     * @param foodName
     */
    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    /**
     * Parse SearchResultPojo into list of SearchResultDTOs
     *
     * @param searchResultPojo
     * @return searchResultDTOs
     */
    public static List<SearchResultDTO> parsePOJO(SearchResultPojo searchResultPojo) {
        //Declare New ArrayList of SearchResultDTOs for returning later once populated
        List<SearchResultDTO> searchResultDTOs = new ArrayList<>();

        //Loop through each food object in searchResultPOJO
        for (Food food : searchResultPojo.getFoods()) {

            //Declare Vars That Will Be Mapped From Food To SearchResultDTOs
            String foodName = food.getDescription();
            double kcal, protein, carbs, fat;
            kcal = protein = carbs = fat = 0;

            //Loop each foodNutrient in the Food object and map it to the
            //correct SearchResultDTO object fields
            for (FoodNutrient foodNutrient : food.getFoodNutrients()) {
                double value = foodNutrient.getValue();
                switch (foodNutrient.getNutrientId()) {
                    case 1008:
                        kcal = value;
                        break;
                    case 1003:
                        protein = value;
                        break;
                    case 1005:
                        carbs = value;
                        break;
                    case 1004:
                        fat = value;
                        break;
                }

            }
            //Create a new SearchResultDTO object with each of the fields mapped
            //and add to searchResultDTOs ArrayList
            searchResultDTOs.add(new SearchResultDTO(kcal, protein, carbs, fat, foodName));

        }
        return searchResultDTOs;

    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(this.foodName)
                .append('\t')
                .append(this.kcal);

        return builder.toString();
    }
}
