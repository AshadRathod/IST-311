package UI;

import Models.SearchResultDTO;
import Services.DatabaseService;
import Services.Repository;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;

/**
 * UI Controller
 *
 * @author NathanParker
 */
public class Controller implements Initializable {

    //Declare References to UI Items that are in 
    @FXML
    private TextField searchBar; //Search Bar

    @FXML
    private ListView<String> listView; //Results List View

    @FXML
    private Label totalCaloriesLabel; //Label For Total Calories Value

    @FXML
    private Label lastFoodNameLabel; //Label for Last Food Name

    //Declare a list of SearchResultDTO objects for the 
    //result and an instance of the DatabaseService
    List<SearchResultDTO> result;
    DatabaseService dbService = new DatabaseService();

    /**
     * Search Button Clicked
     *
     */
    @FXML
    void search(ActionEvent event) {
        //Clear the previous result if there
        result = null;

        //Get the result from the searchFood method
        result = Repository.searchFood(searchBar.getText());
        System.out.println(searchBar.getText());

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            System.out.println("ERROR: " + e);
        }

        //Clear the ListView if it is already populated
        listView.getItems().clear();

        //Add all of the results to the List View
        listView.getItems().addAll(
                result.stream()
                        .map(SearchResultDTO::toString)
                        .collect(Collectors.toList())
        );

    }

    /**
     * Save Button Clicked
     *
     */
    @FXML
    void save(ActionEvent event) {

        if (listView.getSelectionModel().getSelectedIndex() > -1) {
            dbService.saveFoodItem(result.get(listView.getSelectionModel().getSelectedIndex()));

            //Update The Total Calories & Last Food Name Labels to reflect changes
            totalCaloriesLabel.setText(String.valueOf(dbService.getTotalCalories()));
            lastFoodNameLabel.setText(dbService.getLastFoodItemName());
        } else {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Selection Error");
            alert.setHeaderText("No Food Item Selected");
            alert.setContentText("Please first select a food item before clicking save.");

            alert.showAndWait();
        }

    }

    /**
     * Initialize UI
     *
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        totalCaloriesLabel.setText(String.valueOf(dbService.getTotalCalories()));
        lastFoodNameLabel.setText(dbService.getLastFoodItemName());
    }

    //Under Development
//    private List<String> searchList(String searchWords, List<String> listOfStrings) {
//
//        List<String> searchWordsArray = Arrays.asList(searchWords.trim().split(" "));
//
//        return listOfStrings.stream().filter(input -> {
//            return searchWordsArray.stream().allMatch(word
//                    -> input.toLowerCase().contains(word.toLowerCase()));
//        }).collect(Collectors.toList());
//    }
}
