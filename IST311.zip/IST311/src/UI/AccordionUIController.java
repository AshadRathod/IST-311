/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author ashadrathod
 */
public class AccordionUIController implements Initializable {

    @FXML
    private TextField CaloriesBar;
    @FXML
    private TextField ProteinBar;
    @FXML
    private TextField FatsBar;
    @FXML
    private TextField CarbsBar;
    @FXML
    private TextField CaloriesBar1;
    @FXML
    private TextField ProteinBar1;
    @FXML
    private TextField FatsBar1;
    @FXML
    private TextField CarbsBar1;
    @FXML
    private TextField CaloriesBar2;
    @FXML
    private TextField ProteinBar2;
    @FXML
    private TextField FatsBar2;
    @FXML
    private TextField CarbsBar2;

    /**
     * Initializes the controller class.
     */


    @FXML
    private void delete(ActionEvent event) {
    }

    @FXML
    private void GoBack(ActionEvent event) {
    }
    
     @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
}
