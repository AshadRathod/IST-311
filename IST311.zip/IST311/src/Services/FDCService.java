package Services;

import Models.SearchResultPojo;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * FDC API Service
 *
 * @author NathanParker
 */
public class FDCService {

    //Declare API variables
    public static final String BASE_URL = "https://api.nal.usda.gov/fdc/";
    public static final String API_KEY = "TKfXo4WGBdXO45O5M8cFDJx3kygusxUymgLSBQJd";
    private static IFDCService INSTANCE = null;

    /**
     *
     * @return
     */
    public static IFDCService getClient() {
        if (INSTANCE == null) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            INSTANCE = retrofit.create(IFDCService.class);

        }
        return INSTANCE;
    }

    /**
     *
     * @param foodName
     * @return
     */
    public static Call<SearchResultPojo> searchFoodByName(String foodName) {
        return getClient().searchFoodByName(foodName, API_KEY);
    }
}
