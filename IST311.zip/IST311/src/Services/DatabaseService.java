package Services;

import Models.Database;
import Models.SearchResultDTO;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Service That Handles Interactions with the Database Object Such as
 * Serializing and De-serializing the object in XML format and reading / writing
 * it to a file
 *
 * @author NathanParker
 */
public class DatabaseService {

    //Declare A File With FileName to be stored and read to / from
    private static final File DATABASE_FILE = new File("alpha-db.xml");
    private Database databaseObject; //Declare dataBase object
    XStream xstream; //Declare xstream for XML object serialization

    /**
     * DatabaseService Constructor
     */
    public DatabaseService() {
        //Initialize xstream object and declare alias' for persistence storage
        xstream = new XStream(new StaxDriver());
        xstream.alias("foodItem", SearchResultDTO.class);
        xstream.alias("foodList", Database.class);
        xstream.addImplicitCollection(Database.class, "foodList", SearchResultDTO.class);

        //Populate the Database Object from the file if it already exists
        populateDatabase();
    }

    /**
     * Populate Database Object from file if it already exists Otherwise create
     * a new database object
     */
    private void populateDatabase() {
        //Try to read the xml from the file
        try {
            //Declare a file reader and then parse the XML to the databaseObject
            FileReader reader = new FileReader(DATABASE_FILE);
            databaseObject = (Database) xstream.fromXML(reader);

        } catch (IOException ex) {
            //If there was an error reading the file, just create a new databaseObject
            System.out.println(ex);
            databaseObject = new Database();
        }
    }

    /**
     * Serialize the database object to XML and save it to a file
     */
    private void saveDatabase() {

        String xml = xstream.toXML(this.databaseObject);
        System.out.println(xml);

        try (PrintWriter out = new PrintWriter(DATABASE_FILE)) {
            out.println(xml);

        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Add the item to the database object and then call the save method to save
     * the object to a file
     *
     * @param foodItem
     */
    public void saveFoodItem(SearchResultDTO foodItem) {
        //send over to be added to the database list object
        databaseObject.addFoodItem(foodItem);
        saveDatabase();

    }

    /**
     * Get the total calories from the database object
     *
     * @return databaseObject totalCalories
     */
    public double getTotalCalories() {
        return databaseObject.getTotalCalories();
    }

    /**
     * Get the name of the most recent food item in 
     * the database or "N/A" if no items
     *
     * @return databaseObject Last Item Food Name
     */
    public String getLastFoodItemName() {
        if (databaseObject.getFoodList().size() > 0) {
            return databaseObject.getFoodList().get(databaseObject.getFoodList().size() - 1).getFoodName();
        } else {
            return "N/A";
        }
    }

}
